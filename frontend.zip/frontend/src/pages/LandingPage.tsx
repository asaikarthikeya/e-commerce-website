// frontend/src/pages/LandingPage.tsx
import React from 'react';
import Hero from '../components/Hero';

const LandingPage: React.FC = () => {
  return (
    <div>
      <Hero />
      <section className="text-center mt-10">
        <h2 className="text-2xl font-semibold">Shop Our Latest Products</h2>
        {/* Later: add product cards */}
      </section>
    </div>
  );
};

export default LandingPage;