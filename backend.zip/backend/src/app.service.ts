import { Injectable } from '@nestjs/common';

@Injectable()
export class AppService {
  getHeroContent() {
    return {
      title: 'Welcome to Our E-Commerce Store',
      subtitle: 'Shop amazing products at amazing prices!',
    };
  }
}